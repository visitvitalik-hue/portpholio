import React, { useEffect, useState } from 'react'
import './App.css'
import MiniAppCard from './components/MiniAppCard'
import Header from './components/Header'
import LoadingScreen from './components/LoadingScreen'

function App() {
  const [apps, setApps] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [webApp, setWebApp] = useState(null)

  useEffect(() => {
    // Инициализация Telegram WebApp
    const tg = window.Telegram?.WebApp
    if (tg) {
      tg.ready()
      tg.expand()
      setWebApp(tg)
    }

    // Загрузка данных Mini Apps
    const fetchApps = async () => {
      try {
        setLoading(true)
        const response = await fetch('/data/apps.json')
        if (!response.ok) throw new Error('Failed to load apps')
        const data = await response.json()
        setApps(data.apps || [])
      } catch (err) {
        setError(err.message)
        console.error('Error loading apps:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchApps()
  }, [])

  const handleContactAuthor = async (appId, authorName) => {
    if (!webApp) {
      alert('Telegram WebApp не инициализирован')
      return
    }

    try {
      // Получаем initData для отправки на сервер
      const initData = webApp.initData

      if (!initData) {
        alert('Не удалось получить данные авторизации')
        return
      }

      // Отправляем запрос на бэкенд для проверки и обработки
      const response = await fetch('/api/contact-author', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          initData,
          appId,
          authorName,
          queryId: webApp.queryId
        })
      })

      const result = await response.json()

      if (response.ok) {
        webApp.showAlert(`✓ Запрос отправлен автору ${authorName}!\nОни скоро свяжутся с вами.`)
        webApp.close()
      } else {
        webApp.showAlert(`✗ Ошибка: ${result.error || 'Не удалось отправить запрос'}`)
      }
    } catch (err) {
      console.error('Error contacting author:', err)
      webApp?.showAlert(`✗ Ошибка сети: ${err.message}`)
    }
  }

  if (loading) {
    return <LoadingScreen />
  }

  return (
    <div className="app-container">
      <div className="glow-bg"></div>
      <Header appsCount={apps.length} />
      
      <main className="apps-container">
        {error && (
          <div className="error-message">
            <span className="error-icon">⚠</span>
            {error}
          </div>
        )}
        
        {apps.length === 0 && !error ? (
          <div className="empty-state">
            <p className="empty-icon">&gt;_</p>
            <p>Нет приложений для отображения</p>
          </div>
        ) : (
          <div className="cards-grid">
            {apps.map((app, index) => (
              <MiniAppCard
                key={app.id || index}
                app={app}
                onContactAuthor={handleContactAuthor}
              />
            ))}
          </div>
        )}
      </main>

      <footer className="app-footer">
        <div className="footer-line"></div>
        <p className="footer-text">&lt;&nbsp;CYBERMINI&nbsp;&gt;</p>
      </footer>
    </div>
  )
}

export default App
