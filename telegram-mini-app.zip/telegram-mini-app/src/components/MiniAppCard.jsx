import React, { useState } from 'react'
import './MiniAppCard.css'

function MiniAppCard({ app, onContactAuthor }) {
  const [isHovering, setIsHovering] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleContactClick = async () => {
    setIsLoading(true)
    try {
      await onContactAuthor(app.id, app.author)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div 
      className={`mini-app-card ${isHovering ? 'hover' : ''}`}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Анимированная граница */}
      <div className="card-border"></div>

      {/* Содержимое карточки */}
      <div className="card-content">
        {/* Заголовок с иконкой */}
        <div className="card-header">
          <span className="app-icon">{app.icon || '⚡'}</span>
          <h3 className="app-name">{app.name}</h3>
        </div>

        {/* Описание */}
        <p className="app-description">
          {app.description}
        </p>

        {/* Статистика и теги */}
        <div className="card-stats">
          <div className="stat">
            <span className="stat-label">VERSION</span>
            <span className="stat-value">{app.version || '1.0.0'}</span>
          </div>
          <div className="stat">
            <span className="stat-label">SIZE</span>
            <span className="stat-value">{app.size || '~2.5MB'}</span>
          </div>
          <div className="stat">
            <span className="stat-label">USERS</span>
            <span className="stat-value">{app.users || 'N/A'}</span>
          </div>
        </div>

        {/* Категория */}
        {app.category && (
          <div className="app-category">
            <span className="category-tag">[{app.category.toUpperCase()}]</span>
          </div>
        )}

        {/* Кнопка контакта */}
        <button
          className={`contact-btn ${isLoading ? 'loading' : ''}`}
          onClick={handleContactClick}
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <span className="loading-spinner"></span>
              ОТПРАВКА...
            </>
          ) : (
            <>
              <span className="btn-icon">→</span>
              СВЯЗАТЬСЯ С {app.author.toUpperCase()}
            </>
          )}
        </button>

        {/* Техническая информация */}
        {app.tech && (
          <div className="tech-info">
            <span className="tech-label">STACK:</span>
            <code className="tech-stack">{app.tech.join(' / ')}</code>
          </div>
        )}
      </div>

      {/* Декоративные элементы */}
      <div className="card-corner corner-top-left"></div>
      <div className="card-corner corner-top-right"></div>
      <div className="card-corner corner-bottom-left"></div>
      <div className="card-corner corner-bottom-right"></div>
    </div>
  )
}

export default MiniAppCard
