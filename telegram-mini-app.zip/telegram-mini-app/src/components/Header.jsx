import React from 'react'
import './Header.css'

function Header({ appsCount }) {
  return (
    <header className="app-header">
      <div className="header-content">
        <div className="logo">
          <span className="logo-icon">◆</span>
          <h1 className="logo-text">CYBERMINI</h1>
        </div>
        <div className="header-status">
          <span className="status-indicator"></span>
          <span className="status-text">{appsCount} APPS LOADED</span>
        </div>
      </div>
      <div className="header-line"></div>
    </header>
  )
}

export default Header
