import React from 'react'
import './LoadingScreen.css'

function LoadingScreen() {
  return (
    <div className="loading-screen">
      <div className="loading-content">
        <div className="loading-icon">◆</div>
        <h2 className="loading-title">CYBERMINI</h2>
        <div className="loading-bar">
          <div className="loading-progress"></div>
        </div>
        <p className="loading-text">Initializing system...</p>
      </div>
    </div>
  )
}

export default LoadingScreen
