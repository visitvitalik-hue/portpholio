import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import { validateTelegramWebAppData, parseInitData } from './utils/validation.js'
import { answerCallbackQuery, sendMessage } from './utils/telegram.js'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001
const BOT_TOKEN = process.env.BOT_TOKEN
const OWNER_ID = process.env.OWNER_ID

// Middleware
app.use(express.json())
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST'],
  credentials: true
}))

// Логирование запросов
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`)
  next()
})

/**
 * Эндпоинт для контакта с автором Mini App
 * POST /api/contact-author
 */
app.post('/api/contact-author', async (req, res) => {
  try {
    const { initData, appId, authorName, queryId } = req.body

    // Валидация входных данных
    if (!initData || !appId || !authorName) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: initData, appId, authorName'
      })
    }

    if (!BOT_TOKEN) {
      console.error('BOT_TOKEN not configured')
      return res.status(500).json({
        success: false,
        error: 'Server configuration error'
      })
    }

    // ===== КРИТИЧЕСКАЯ ПРОВЕРКА БЕЗОПАСНОСТИ =====
    // Проверяем подпись initData
    const isValidData = validateTelegramWebAppData(initData, BOT_TOKEN)

    if (!isValidData) {
      console.warn('Invalid Telegram WebApp data signature detected')
      return res.status(401).json({
        success: false,
        error: 'Invalid authentication data. Signature verification failed.'
      })
    }

    // Парсим данные пользователя
    const userData = parseInitData(initData)

    // Проверяем свежесть данных (не старше 5 минут)
    if (!userData.isValid) {
      return res.status(401).json({
        success: false,
        error: 'Authentication data expired'
      })
    }

    const userId = userData.user?.id
    const userName = userData.user?.username || userData.user?.first_name || 'Unknown'

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'User information not found in initData'
      })
    }

    // ===== ЛОГИРОВАНИЕ И ОБРАБОТКА =====
    console.log(`[CONTACT] User ${userId} (${userName}) wants to contact author of ${appId}`)

    // Отправляем ответ пользователю
    if (queryId) {
      await answerCallbackQuery(
        queryId,
        BOT_TOKEN,
        `✓ Ваш запрос отправлен автору ${authorName}`,
        false
      )
    }

    // Если установлен OWNER_ID, отправляем уведомление владельцу бота
    if (OWNER_ID) {
      const notificationText = `
📬 Новый запрос на контакт

👤 Пользователь: ${userName} (@${userData.user?.username || 'N/A'})
🆔 User ID: ${userId}
📱 App ID: ${appId}
✍️ Автор: ${authorName}

Время: ${new Date().toISOString()}
      `.trim()

      await sendMessage(
        OWNER_ID,
        BOT_TOKEN,
        notificationText,
        { parse_mode: 'HTML' }
      )
    }

    // ===== УСПЕШНЫЙ ОТВЕТ =====
    return res.json({
      success: true,
      message: 'Contact request sent successfully',
      data: {
        userId,
        userName,
        appId,
        authorName,
        timestamp: new Date().toISOString()
      }
    })

  } catch (error) {
    console.error('Error processing contact-author request:', error)
    return res.status(500).json({
      success: false,
      error: 'Internal server error',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    })
  }
})

/**
 * Health check эндпоинт
 */
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  })
})

/**
 * Информация о сервере (без чувствительных данных)
 */
app.get('/api/info', (req, res) => {
  res.json({
    service: 'Telegram Mini App Backend',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'production'
  })
})

/**
 * 404 обработчик
 */
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    path: req.path
  })
})

/**
 * Глобальный обработчик ошибок
 */
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err)
  res.status(500).json({
    success: false,
    error: 'Internal server error'
  })
})

// Запуск сервера
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║  TELEGRAM MINI APP BACKEND             ║
║  Server running on port ${PORT}          ║
║  Environment: ${process.env.NODE_ENV || 'production'}                ║
║  BOT_TOKEN configured: ${BOT_TOKEN ? 'YES' : 'NO'}        ║
╚════════════════════════════════════════╝
  `)
})

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server')
  process.exit(0)
})
