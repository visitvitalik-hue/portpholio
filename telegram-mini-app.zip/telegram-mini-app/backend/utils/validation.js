import crypto from 'crypto'

/**
 * Проверяет подпись initData от Telegram WebApp
 * @param {string} initData - Данные от WebApp.initData
 * @param {string} botToken - Токен бота из BotFather
 * @returns {boolean} - Подпись корректна или нет
 */
export function validateTelegramWebAppData(initData, botToken) {
  if (!initData || !botToken) {
    return false
  }

  // Разбираем initData
  const params = new URLSearchParams(initData)
  const hash = params.get('hash')

  if (!hash) {
    return false
  }

  // Создаем проверочную строку
  const dataArray = []
  params.sort() // Сортируем по алфавиту

  for (const [key, value] of params) {
    if (key !== 'hash') {
      dataArray.push(`${key}=${value}`)
    }
  }

  const dataCheckString = dataArray.join('\n')

  // Генерируем HMAC
  const secretKey = crypto
    .createHmac('sha256', 'WebAppData')
    .update(botToken)
    .digest()

  const computedHash = crypto
    .createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex')

  return computedHash === hash
}

/**
 * Парсит initData и возвращает данные пользователя
 * @param {string} initData - Данные от WebApp.initData
 * @returns {object} - Распарсенные данные
 */
export function parseInitData(initData) {
  const params = new URLSearchParams(initData)
  const user = params.get('user') ? JSON.parse(params.get('user')) : null
  const chatInstance = params.get('chat_instance')
  const authDate = params.get('auth_date')
  const queryId = params.get('query_id')
  const startParam = params.get('start_param')

  return {
    user,
    chatInstance,
    authDate: new Date(parseInt(authDate) * 1000),
    queryId,
    startParam,
    isValid: authDate && parseInt(authDate) > Date.now() / 1000 - 300 // Последние 5 минут
  }
}
