/**
 * Отправляет ответ на callback query боту
 * @param {string} queryId - ID query от пользователя
 * @param {string} botToken - Токен бота
 * @param {string} notificationText - Текст уведомления
 * @param {boolean} showAlert - Показать как alert (true) или toast (false)
 * @returns {Promise<boolean>} - Успешность отправки
 */
export async function answerCallbackQuery(
  queryId,
  botToken,
  notificationText = null,
  showAlert = false
) {
  try {
    const url = `https://api.telegram.org/bot${botToken}/answerCallbackQuery`

    const body = {
      callback_query_id: queryId,
      show_alert: showAlert
    }

    if (notificationText) {
      body.text = notificationText
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    })

    if (!response.ok) {
      const error = await response.json()
      console.error('Telegram API error:', error)
      return false
    }

    return true
  } catch (error) {
    console.error('Error sending callback query answer:', error)
    return false
  }
}

/**
 * Отправляет сообщение пользователю через бота
 * @param {number} userId - Telegram ID пользователя
 * @param {string} botToken - Токен бота
 * @param {string} text - Текст сообщения
 * @param {object} options - Дополнительные опции (reply_markup, parse_mode и т.д.)
 * @returns {Promise<boolean>} - Успешность отправки
 */
export async function sendMessage(userId, botToken, text, options = {}) {
  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`

    const body = {
      chat_id: userId,
      text,
      ...options
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    })

    if (!response.ok) {
      const error = await response.json()
      console.error('Telegram API error:', error)
      return false
    }

    return true
  } catch (error) {
    console.error('Error sending message:', error)
    return false
  }
}
